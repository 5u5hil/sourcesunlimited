<?php get_header();

?>

<div class="parallax full-width-bg lr_widget">

    <div class="container">

        <div class="main-title">

         



            <div class="column dt-sc-three-fifth first">

            <h1>Profile</h1>

		</div>

<!--		<div class="column dt-sc-two-fifth first ">

           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>

		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 



		</div>-->

            

            

        </div>

    </div>

</div>

<!-- Container starts-->

<div class="full-width-section ">

				<div class="dt-sc-margin30"></div> 

                <div class="container">
 <!-- **dt-sc-team - Ends** -->
 
 
 <div class="column dt-sc-one-second" style="text-align:justify;">
					 
                        <!-- **dt-sc-team - Starts** -->
                        <div class="dt-sc-team type2">
                        	<div class="image">
	                          <img src="<?= get_template_directory_uri() ?>/images/sonias.jpg" alt="image"/> 
	                            <h6>Sonia Sharma</h6>
	                            <p>IMT Ghaziabad</p>
                            </div>
                            <p style="text-align:justify;">Sonia has 15 years of experience in Banking, Strategy & Operations and Entrepreneurship. She has held leadership positions across various well-known companies in India and Abroad. She founded four companies and has an excellent track record of building businesses from scratch. Sonia has incubated companies in Human Resource Outsourcing (HRO), Hospitality and Healthcare industries. She has been involved in various Mergers and Acquisitions activities of her companies and has dealt with Private Equity and Venture Capital funds as an entrepreneur.<br /><br />

She holds a B.A. in Economics from Delhi University and dual MBA degrees in Marketing and Finance from Cleveland State University, Cleveland, Ohio and IMT, Ghaziabad.<br />   </p>
			 </div>


 
 <div class="dt-sc-team type3">
                        	
                         
						 
                        </div>



					</div><!-- **dt-sc-team - Ends** -->
									
				</div>
				
				
 
 
 
 
 
 
 
									
				</div>
		   
		   
 </div>

 

   

                <div class="dt-sc-margin50"></div> 


			

			

			

<div class="dt-sc-margin65"></div>  

	

					

			 <!-- **container - Ends** --> 

<?php get_footer(); ?>