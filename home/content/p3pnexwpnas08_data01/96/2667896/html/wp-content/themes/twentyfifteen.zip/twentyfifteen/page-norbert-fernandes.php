<?php get_header();

?>

<div class="parallax full-width-bg lr_widget">

    <div class="container">

        <div class="main-title">

         



            <div class="column dt-sc-three-fifth first">

            <h1>Profile</h1>

		</div>

<!--		<div class="column dt-sc-two-fifth first ">

           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>

		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 



		</div>-->

            

            

        </div>

    </div>

</div>

<!-- Container starts-->

<div class="full-width-section ">

				<div class="dt-sc-margin30"></div> 

                <div class="container">
 <!-- **dt-sc-team - Ends** -->
 
 
 <div class="column dt-sc-one-second" style="text-align:justify;">
					 
                        <!-- **dt-sc-team - Starts** -->
                        <div class="dt-sc-team type2">
                        	<div class="image">
	                          <img src="<?= get_template_directory_uri() ?>/images/norbert.jpg" style="margin-left: 25px;" alt="image"/> 
	                            <h6>Mr. Norbert Fernandes</h6>
	                            <p>IIT Kanpur, IIM Calcutta</p>
                            </div>
                            <p style="text-align:justify;">With prior deep investing experience with Temasek Holdings (a Singapore based investment company that manages an Asia focused portfolio of $142bn) across Singapore and Mumbai, Norbert has investing experience spanning multiple sectors and was instrumental in completing 4 transactions including a landmark $200mn structured primary investment in an unlisted Indian power generation company. He was the Investment Officer responsible for managing and monitoring 4 India portfolio companies worth $1 bn + of equity. He completed a $25mn partial divestment in an Indian agribusiness co. and a $40mn partial divestment in a listed Indian bank. Graduate from IIT Kanpur, IIM Calcutta..Norbert is a Co-Founder and Principal at IvyCap Ventures.<br />   </p>
			 </div>

 
 <div class="dt-sc-team type3">
                        	
                         
						 
                        </div>



					</div><!-- **dt-sc-team - Ends** -->
									
				</div>
				
				
 
 
 
 
 
 
 
									
				</div>
		   
		   
 </div>

 

   

                <div class="dt-sc-margin50"></div> 


			

			

			

<div class="dt-sc-margin65"></div>  

	

					

			 <!-- **container - Ends** --> 

<?php get_footer(); ?>