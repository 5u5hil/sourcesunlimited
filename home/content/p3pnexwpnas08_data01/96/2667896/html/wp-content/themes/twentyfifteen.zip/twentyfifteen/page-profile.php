<?php
//check_startup();

get_header();
?>
<div class="parallax full-width-bg lr_widget">
    <div class="container">
        <div class="main-title">
            <div class="column dt-sc-three-fifth first">
                <h1>Profile</h1>
            </div>

        </div>
    </div>
</div>
<div class="dt-sc-margin30"></div>
<div class="container">
    <!-- **secondary - starts** --> 
    <section id="secondary-left" class="secondary-sidebar secondary-has-left-sidebar">
        <aside class="widget widget_product_categories">
            <ul>
                <li> <a href="#">Dashboard</a> </li>
                <li> <a href="/investor-listing">Investors</a> </li>
                <li> <a href="/mentor-listing">Mentors</a> </li>
                <li> <a href="/corporate-listing">Corporates</a> </li>
                <li> <a href="/institute-listing">Institute</a> </li>
                <li> <a href="/funding-eligiblility-question/">Funding Eligibility Questioners</a> </li>
                <li> <a href="#">Edit Profile</a> </li>
            </ul>	
        </aside>	 
    </section> <!-- **secondary - Ends** -->  

    <!-- **primary - Starts** --> 
    <section id="primary" class="with-left-sidebar page-with-sidebar">


	
	
	
	


	<!-- **product - Ends** -->
        <div class="dt-sc-margin10"></div>
        <!-- **pagination - Starts** -->  
<!--        <div class="pagination">
            <div class="prev-post"> <a href="#"> <span class="fa fa-caret-left"></span> PREV </a> </div>
            <ul>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">4</a></li>
            </ul>
            <div class="next-post"> <a href="#">NEXT  <span class="fa fa-caret-right"></span> </a> </div>
        </div>  **pagination - Ends** -->
    </section> <!-- **primary - Ends** --> 
    <div class="dt-sc-margin80"></div>
</div>
<div class="dt-sc-hr-invisible"></div>		 <!-- **container - Ends** --> 
<?php get_footer(); ?>