<?php get_header();

?>

<div class="parallax full-width-bg lr_widget">

    <div class="container">

        <div class="main-title">

         



            <div class="column dt-sc-three-fifth first">

            <h1>Profile</h1>

		</div>

<!--		<div class="column dt-sc-two-fifth first ">

           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>

		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 



		</div>-->

            

            

        </div>

    </div>

</div>

<!-- Container starts-->

<div class="full-width-section ">

				<div class="dt-sc-margin30"></div> 

                <div class="container">
 <!-- **dt-sc-team - Ends** -->
 
 
 <div class="column dt-sc-one-second" style="text-align:justify;">
					 
                        <!-- **dt-sc-team - Starts** -->
                        <div class="dt-sc-team type2">
                        	<div class="image">
	                          <img src="<?= get_template_directory_uri() ?>/images/shirish.jpg" alt="image"/> 
	                            <h6>Mr. Shirish Potnis</h6>
	                            <p>IIT Bombay, IIM Calcutta</p>
                            </div>
                            <p style="text-align:justify;">Shirish Potnis is an alumnus of IIT Bombay (B. Tech in Chem Engg 1976) and also of IIM Calcutta.<br /><br />

Shirish has had a career spanning more than three decades across a variety of industries like chemicals, pharmaceuticals, food processing, infrastructure and consultancy handling corporate planning, identifying and planning new initiatives and taking them to fruition. His past corporate stints include Lupin Labs, United Breweries, Simplex Infrastructure each of which saw him handle a large and varied mix of assignments. His work with different projects has taken him to more than 20 countries.<br />
<br />
A strong commitment to alma mater prompted Shirish to assume the role of CEO of IIT Bombay Alumni Association and then of an Advisor to an Innovation Lab operating out of IIT Bombay. He has been associated with IvyCap Ventures from the inception as a Mentor and is now nurturing IvyCamp.<br />   </p>
			 </div>




 <div class="dt-sc-team type3">
                        	
                         
						 
                        </div>



					</div><!-- **dt-sc-team - Ends** -->
									
				</div>
				
				
 
 
 
 
 
 
 
									
				</div>
		   
		   
 </div>

 

   

                <div class="dt-sc-margin50"></div> 


			

			

			

<div class="dt-sc-margin65"></div>  

	

					

			 <!-- **container - Ends** --> 

<?php get_footer(); ?>