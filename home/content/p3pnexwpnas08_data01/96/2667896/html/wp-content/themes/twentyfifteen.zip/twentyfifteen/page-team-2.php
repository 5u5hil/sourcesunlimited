<?php get_header();
?>
<div class="parallax full-width-bg lr_widget">
    <div class="container">
        <div class="main-title">
         

            <div class="column dt-sc-three-fifth first">
            <h1>Team</h1>
		</div>
<!--		<div class="column dt-sc-two-fifth first ">
           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>
		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 

		</div>-->
            
            
        </div>
    </div>
</div>
<!-- Container starts-->
<div class="full-width-section grey1">
				<div class="dt-sc-margin30"></div> 
                <div class="container">
                    <div class="hr-title dt-sc-hr-invisible-small">
                            <h2>Meet Our Team </h2>
                            <div class="title-sep"> </div>
                    </div>
                    <!-- **column - Starts** -->
                    <div class="">
                    	<p class="text-justify">The team collectively bring with them an experienced investment background, strong ties to the alumni community, experience working across educational institutions in India and the US, and a passion for growing our innovation and startup ecosystem.</p>
                                                
                        <div class="dt-sc-margin25"></div>
                        </div>
                    
                   
                </div>
                
				
				 <div class="container">
							<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/anju.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/anju-gupta/">Dr. Anju Gupta, Ph.D</a></h6>
                                            <p>IIT Delhi,  M.S &amp; PhD California</p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                       <div style="clear:both; "></div>
                                        <ul class="dt-sc-social-icons">
											<li> <a href="http://www.twitter.com/anju_ivycamp" target="_blank" title="twitter"> <span class="fa fa-twitter"></span>  </a> </li>
											<li> <a href="https://www.linkedin.com/profile/view?id=4968164&authType=NAME_SEARCH&authToken=X6HO&locale=en_US&srchid=49681641430066393168&srchindex=1&srchtotal=255&trk=vsrp_people_res_name&trkInfo=VSRPsearchId%3A49681641430066393168%2CVSRPtargetId%3A4968164%2CVSRPcmpt%3Aprimary%2CVSRPnm%3Aanju" target="_blank" title="linkedin"> <span class="fa fa-linkedin"></span>  </a> </li>
                                        </ul> <!-- **dt-sc-social-icons - Ends** -->
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>
								
								
							<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/vikram.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/vikram-gupta">Mr. Vikram Gupta</a></h6>
                                            <p>IIT Delhi </p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                       <div style="clear:both; "></div> 
									   <ul class="dt-sc-social-icons">											
									  <!-- <li> <a href="#" title="twitter"> <span class="fa fa-twitter"></span>  </a> </li>-->											
									   <li> <a href="https://www.linkedin.com/profile/view?id=7130714&authType=NAME_SEARCH&authToken=Ee4Q&locale=en_US&trk=tyah&trkInfo=clickedVertical%3Amynetwork%2Cidx%3A1-1-1%2CtarId%3A1430066427528%2Ctas%3Avikram" target="_blank" title="linkedin"> <span class="fa fa-linkedin"></span>  </a> </li>                                        </ul> <!-- **dt-sc-social-icons - Ends** -->
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>	
								
							
						<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/shirish.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/shirish-potnis/">Mr. Shirish Potnis</a></h6>
                                            <p>IIT Bombay, IIM Calcutta </p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                      <div style="clear:both; "></div>                                       
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>


						<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/norbert.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/norbert-fernandes/">Norbert Fernandes</a></h6>
                                            <p> IIT Kanpur, IIM Calcutta</p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                       <div style="clear:both; "></div>              
									   <ul class="dt-sc-social-icons">											
																			<li> <a href="https://www.linkedin.com/profile/view?id=4383269&authType=NAME_SEARCH&authToken=aX3b&locale=en_US&trk=tyah&trkInfo=clickedVertical%3Amynetwork%2Cidx%3A1-1-1%2CtarId%3A1430066463983%2Ctas%3Anorbert" target="_blank" title="linkedin"> <span class="fa fa-linkedin"></span>  </a> </li>                                        </ul> <!-- **dt-sc-social-icons - Ends** -->
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>


						<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/ashish.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/ashish-wadhwani/">Ashish Wadhwani</a></h6>
                                            <p>IIT Delhi, IIM Ahmedabad</p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                       <div style="clear:both; "></div>                                       
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>


					<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/prayag.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/prayag-mohanty/">Prayag Mohanty</a></h6>
                                            <p>PGDM XIM</p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                      <div style="clear:both; "></div>                                        <ul class="dt-sc-social-icons">																						<li> <a href="https://www.linkedin.com/profile/view?id=55856791&authType=NAME_SEARCH&authToken=tLod&locale=en_US&trk=tyah&trkInfo=clickedVertical%3Amynetwork%2Cidx%3A1-1-1%2CtarId%3A1430066502575%2Ctas%3Aprayag" target="_blank" title="linkedin"> <span class="fa fa-linkedin"></span>  </a> </li>                                        </ul> <!-- **dt-sc-social-icons - Ends** -->
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>
								
								
						<div class="column dt-sc-one-fourth col4">
                                    <!-- **dt-sc-team - Starts** -->
                                    <div class="dt-sc-team">
                                        <div class="image"><img src="http://ivycamp.cruxservers.in/wp-content/themes/twentyfifteen/images/sonias.jpg" alt="iamge"></div>
                                        <!-- **team-details - Starts** -->
                                        <div class="team-details">
                                            <h6><a href="/sonia-sharma/">Sonia Sharma</a></h6>
                                            <p>IMT Ghaziabad</p>
                                        </div> <!-- **team-details - Ends** -->
                                        <!-- **dt-sc-social-icons - Starts** -->
                                        <div style="clear:both; "></div>                                     
                                    </div><!-- **dt-sc-team - Ends** -->
                                </div>		
							
								
				
				  </div>
				
				
                <div class="dt-sc-margin50"></div> 												
            </div>
			
			
			
	
					
			 <!-- **container - Ends** --> 
<?php get_footer(); ?>