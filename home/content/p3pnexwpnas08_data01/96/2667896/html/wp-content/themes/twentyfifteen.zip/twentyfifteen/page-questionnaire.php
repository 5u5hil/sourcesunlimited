<?php get_header();
?>
<div class="parallax full-width-bg lr_widget">
    <div class="container">
        <div class="main-title">
         

            <div class="column dt-sc-three-fifth first">
            <h1>Instructions of IvyCamp Questionnaire</h1>
		</div>
<!--		<div class="column dt-sc-two-fifth first ">
           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>
		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 

		</div>-->
            
            
        </div>
    </div>
</div>
<!-- Container starts-->
<div class="full-width-section grey1">
				<div class="dt-sc-margin30"></div> 
                
                       <div class="container">          
                    
                    <!-- **column - Ends** -->
                    <!-- **column - Starts** -->
                   <!-- **column - Ends** -->
                
                   <div class="hr-title dt-sc-hr-invisible-small">
                            <h2>Title Goes Here</h2>
                            <div class="title-sep"> </div>
                    </div>
                    <!-- **column - Starts** -->
                    <div class="column dt-sc-five-fifth first">
                      <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged</p>  
					  
					  <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to:</p>
                    </div> 
					
					
					<div class="column dt-sc-five-fifth first">
                        <ul class="dt-sc-fancy-list arrow lcolor">
                            <li>To build a unified platform for innovation and entrepreneurship across India’s Educational Institutions.</li>
                            <li>To establish high quality engagement entrepreneurs with through a highly organized Mentor program.</li>
							<li>To build a unified platform for innovation and entrepreneurship across India’s Educational Institutions.</li>
                            <li>To establish high quality engagement entrepreneurs with through a highly organized Mentor program.</li>
                            <li>To leverage the power of the Global Alumni Networks to promote thousands of entrepreneurs from India.</li>
							<li>To cultivate and foster innovation, support IP generation, and help transform innovative ideas into commercial value that will influence 
								our economy and technical progress.
							</li>
						</ul>
                    </div>
                    
                    <div class="clr"></div>
               <a href="http://ivycamp.in/funding-eligiblility-question/"> <button class="button" style="background-color: #006b3b; border:0;" >Start Questionnaire</button></a>
                 
              
             
                       
                        <div class="dt-sc-margin50"></div> 	
                                
                    </div>
                  
                   
                </div> <!-- **container - Ends** -->
              											
            </div>
			
			
			
	
					
			 <!-- **container - Ends** --> 
<?php get_footer(); ?>