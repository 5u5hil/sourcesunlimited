<?php get_header();

?>

<div class="parallax full-width-bg lr_widget">

    <div class="container">

        <div class="main-title">

         



            <div class="column dt-sc-three-fifth first">

            <h1>Profile</h1>

		</div>

<!--		<div class="column dt-sc-two-fifth first ">

           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>

		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 



		</div>-->

            

            

        </div>

    </div>

</div>

<!-- Container starts-->

<div class="full-width-section ">

				<div class="dt-sc-margin30"></div> 

                <div class="container">
 <!-- **dt-sc-team - Ends** -->
 
 
 <div class="column dt-sc-one-second" style="text-align:justify;">
					 
                        <!-- **dt-sc-team - Starts** -->
                        <div class="dt-sc-team type2">
                        	<div class="image">
	                          <img src="<?= get_template_directory_uri() ?>/images/ashish.jpg" style="margin-left: 17px;" alt="image"/> 
	                            <h6>Mr. Ashish Wadwani</h6>
	                            <p>IIT Delhi, IIM Ahmedabad</p>
                            </div>
                            <p style="text-align:justify;">Managing Partner at IvyCap, Ashish has led and managed investments of over INR 500 crores, has completed 3 strategic exits and has led a NASDAQ listing of a USD 50mn company. He was involved in a green field steel plant by Tata Steel and several renewable projects for Tata Power. He has co-founded IndAS Green Acquisition Corporation (an investment vehicle set-up to acquire businesses in the energy, alternative energy, environmental industries India & other ASEAN countries). At IndAS he completed the listing process in NASDAQ and identified and evaluated several investments in the wind, solar, bio mass, mini hydro and energy efficiency areas. He holds a PGDM from IIM Ahmedabad, and a B.Tech. degree from IIT Delhi.<br />   </p>
			 </div>



 
 <div class="dt-sc-team type3">
                        	
                         
						 
                        </div>



					</div><!-- **dt-sc-team - Ends** -->
									
				</div>
				
				
 
 
 
 
 
 
 
									
				</div>
		   
		   
 </div>

 

   

                <div class="dt-sc-margin50"></div> 


			

			

			

<div class="dt-sc-margin65"></div>  

	

					

			 <!-- **container - Ends** --> 

<?php get_footer(); ?>