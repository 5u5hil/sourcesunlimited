<?php get_header();

?>

<div class="parallax full-width-bg lr_widget">

    <div class="container">

        <div class="main-title">

         



            <div class="column dt-sc-three-fifth first">

            <h1>Profile</h1>

		</div>

<!--		<div class="column dt-sc-two-fifth first ">

           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>

		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 



		</div>-->

            

            

        </div>

    </div>

</div>

<!-- Container starts-->

<div class="full-width-section ">

				<div class="dt-sc-margin30"></div> 

                <div class="container">
 <!-- **dt-sc-team - Ends** -->
 
 
 <div class="column dt-sc-one-second" style="text-align:justify;">
					 
                        <!-- **dt-sc-team - Starts** -->
                        <div class="dt-sc-team type2">
                        	<div class="image">
	                          <img src="<?= get_template_directory_uri() ?>/images/vikram.jpg" alt="image"/> 
	                            <h6>Mr. Vikram Gupta</h6>
	                            <p>IIT Delhi, MBA</p>
                            </div>
                            <p style="text-align:justify;">Founder and Managing Partner of IvyCap Ventures, Vikram has 16 years of experience in Private Equity, Business Consulting, M&A, Strategy and Operations in Healthcare and Life Sciences, Education and Consumer Goods. Previously, Vikram was the Chief Operating Officer (COO) with India Venture Advisors Pvt. Ltd. Vikram has also held senior positions with Indian companies including A F Ferguson & Co. (now Deloitte Consulting), Dr. Reddy’s Laboratories, Lupin Laboratories and Piramal Healthcare across different areas including Business Consulting, Strategy & Planning, M&A, Business Development and Manufacturing. He completed his B.Tech. in Chemical Engineering from IIT Delhi and has dual MBA degrees in Strategy and Finance from Case Western Reserve University, Cleveland, Ohio, USA and XIM, Bhubaneswar.<br />   </p>
			 </div>



 <div class="dt-sc-team type2" style="margin-left: 195px;">
                        	<div >
	                        <a href="https://www.youtube.com/embed/oWPg2FEePBU" target="_blank">							<!--<iframe style="height: 278px; width: 494px;" src="http://ivycamp.in/bp_upload/Vikram-Gupta.mp4" frameborder="0" allowfullscreen></iframe>-->														<iframe style="height: 278px; width: 494px;" src="https://www.youtube.com/embed/oWPg2FEePBU" frameborder="0" allowfullscreen></iframe>														</a>
                            </div>
                           
							
							
							
                        </div>
 <div class="dt-sc-team type3">
                        	
                         
						 
                        </div>



					</div><!-- **dt-sc-team - Ends** -->
									
				</div>
				
				
 
 
 
 
 
 
 
									
				</div>
		   
		   
 </div>

 

   

                <div class="dt-sc-margin50"></div> 


			

			

			

<div class="dt-sc-margin65"></div>  

	

					

			 <!-- **container - Ends** --> 

<?php get_footer(); ?>