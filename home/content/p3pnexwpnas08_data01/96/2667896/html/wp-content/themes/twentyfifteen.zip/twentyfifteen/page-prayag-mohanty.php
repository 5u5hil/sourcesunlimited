<?php get_header();

?>

<div class="parallax full-width-bg lr_widget">

    <div class="container">

        <div class="main-title">

         



            <div class="column dt-sc-three-fifth first">

            <h1>Profile</h1>

		</div>

<!--		<div class="column dt-sc-two-fifth first ">

           <a class="dt-sc-button large f_right" href="/startupsignup/">Register <span class="fa fa-angle-right"></span></a>

		                           <a class="dt-sc-button large mr10 f_right" href="/login/">Login <span class="fa fa-angle-right"></span></a> 



		</div>-->

            

            

        </div>

    </div>

</div>

<!-- Container starts-->

<div class="full-width-section ">

				<div class="dt-sc-margin30"></div> 

                <div class="container">
 <!-- **dt-sc-team - Ends** -->
 
 
 <div class="column dt-sc-one-second" style="text-align:justify;">
					 
                        <!-- **dt-sc-team - Starts** -->
                        <div class="dt-sc-team type2">
                        	<div class="image">
	                          <img src="<?= get_template_directory_uri() ?>/images/prayag.jpg" style="  margin-left: 21px" alt="image"/> 
	                            <h6>Mr. Prayag Mohanty</h6>
	                            <p>PGDM XIM</p>
                            </div>
                            <p style="text-align:justify;">He worked at SBI Capital Markets (Investment Banking subsidiary of SBI) for 3 years as part of he Capital Markets Group and was involved in the closure of 5 transactions including the marquee follow on public offering of $700 million by Tata Steel. He has worked closely with the Department of Disinvestment for managing the sale of shares by the Government of India including the $200 million stake sale in Engineers India through a follow on public offering and the $110 million stake sale in National Aluminium Company via an offer for sale auction. He has a Post Graduate Diploma in Management with Finance specialisation from XIM, Bhubaneswar and a B.E.(Computer Science) from Pune. Prayag is an Associate at IvyCap Ventures.<br />   </p>
			 </div>
 <div class="dt-sc-team type3">
                        	
                         
						 
                        </div>



					</div><!-- **dt-sc-team - Ends** -->
									
				</div>
				
				
 
 
 
 
 
 
 
									
				</div>
		   
		   
 </div>

 

   

                <div class="dt-sc-margin50"></div> 


			

			

			

<div class="dt-sc-margin65"></div>  

	

					

			 <!-- **container - Ends** --> 

<?php get_footer(); ?>